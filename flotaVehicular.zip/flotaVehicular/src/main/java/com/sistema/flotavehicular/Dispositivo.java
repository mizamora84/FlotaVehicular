
package com.sistema.flotavehicular;

public interface Dispositivo {
    
        void mostrarInfoDispositivo ();
        
    
}
