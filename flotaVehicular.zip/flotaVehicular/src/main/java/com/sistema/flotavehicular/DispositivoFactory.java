package com.sistema.flotavehicular;

public interface DispositivoFactory {
    
        Dispositivo crearDispositivo(String marca,int numero);

        
}