package com.sistema.flotavehicular;

public interface Observer {
    
    void update(String location);
      
}
