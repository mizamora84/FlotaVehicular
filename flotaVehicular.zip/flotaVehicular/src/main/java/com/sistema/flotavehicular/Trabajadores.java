package com.sistema.flotavehicular;

public interface Trabajadores {
    
void mostrarTrabajadores ();

    
}