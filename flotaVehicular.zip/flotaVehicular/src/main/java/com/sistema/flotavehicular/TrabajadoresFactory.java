package com.sistema.flotavehicular;

public interface TrabajadoresFactory {
    
    Trabajadores crearTrabajador(String nombre,int id);

   
}
